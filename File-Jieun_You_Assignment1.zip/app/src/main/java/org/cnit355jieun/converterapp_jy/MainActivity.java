package org.cnit355jieun.converterapp_jy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Time;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends AppCompatActivity {



    Spinner spinner;

    String[] Countries_Currency = {"USD","CAD","CNY","INR","KRW",
            "NTD","MYR","COP","IDR"};

    String[] Countries_Time = {"US","Canada","China","India","Korea",
            "Taiwan","Malaysia","Colombia","Indonesia"};



    Double num = 0.0;

    Double cadVal = 1.3;
    Double korVal = 1181.0;
    Double usVal = 1.0;
    Double indiaVal = 71.0;
    Double colVal = 3453.29;
    Double taiVal = 30.59;
    Double indoVal = 14144.0;
    Double chinaVal=7.08 ;
    Double malayVal =4.19 ;



    ImageView mUSView;
    ImageView mCanadaView;
    ImageView mIndiaView;
    ImageView mKoreaView;
    ImageView mChinaView;
    ImageView mTaiwanView;
    ImageView mMalaysiaView;
    ImageView mColumbiaView;
    ImageView mIndonesiaView;


    TextView mCategoryTextView;
    EditText mEditText;

    TextView mUSText3;
    TextView mUSText4;

    TextView mCanadaText3;
    TextView mCanadaText4;

    TextView mChinatext3;
    TextView mChinatext4;

    TextView mIndiatext3;
    TextView mIndiatext4;

    TextView mKoreatext3;
    TextView mKoreatext4;

    TextView mTaiwantext3;
    TextView mTaiwantext4;

    TextView mMalaysiatext3;
    TextView mMalaysiatext4;

    TextView mColumbiatext3;
    TextView mColumbiatext4;

    TextView mIndonesiatext3;
    TextView mIndonesiatext4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        spinner = (Spinner)findViewById(R.id.spinner);

         mUSView= findViewById(R.id.UnitedStatesView);
         mCanadaView= findViewById(R.id.CanadaView);
         mIndiaView = findViewById(R.id.IndiaView);
         mKoreaView=findViewById(R.id.KoreaView);
         mChinaView=findViewById(R.id.ChinaView);
         mTaiwanView=findViewById(R.id.TaiwanView);
         mMalaysiaView=findViewById(R.id.MalaysiaView);
         mColumbiaView=findViewById(R.id.ColumbiaView);
         mIndonesiaView=findViewById(R.id.IndonesiaView);



         mCategoryTextView = findViewById(R.id.CategoryTextView);


         mUSText3= findViewById(R.id.USText3);
         mUSText4= findViewById(R.id.USText4);

         mCanadaText3= findViewById(R.id.CanadaText3);
         mCanadaText4= findViewById(R.id.CanadaText4);

         mChinatext3= findViewById(R.id.ChinaText3);
         mChinatext4= findViewById(R.id.ChinaText4);

         mIndiatext3= findViewById(R.id.IndiaText3);
         mIndiatext4= findViewById(R.id.IndiaText4);

         mKoreatext3= findViewById(R.id.KoreaText3);
         mKoreatext4= findViewById(R.id.KoreaText4);

         mTaiwantext3= findViewById(R.id.TaiwanText3);
         mTaiwantext4= findViewById(R.id.TaiwanText4);

         mMalaysiatext3= findViewById(R.id.MalaysiaText3);
         mMalaysiatext4= findViewById(R.id.MalaysiaText4);

         mColumbiatext3= findViewById(R.id.ColumbiaText3);
         mColumbiatext4= findViewById(R.id.ColumbiaText4);

         mIndonesiatext3= findViewById(R.id.IndonesiaText3);
        mIndonesiatext4= findViewById(R.id.IndonesiaText4);


        Drawable drawable_US = ResourcesCompat.getDrawable(getResources(),R.drawable.unitedstates,null);
        mUSView.setImageDrawable(drawable_US);

        Drawable drawable_Canada = ResourcesCompat.getDrawable(getResources(),R.drawable.canada,null);
        mCanadaView.setImageDrawable(drawable_Canada);

        Drawable drawable_China = ResourcesCompat.getDrawable(getResources(),R.drawable.china,null);
        mChinaView.setImageDrawable(drawable_China);

        Drawable drawable_India = ResourcesCompat.getDrawable(getResources(),R.drawable.india,null);
        mIndiaView.setImageDrawable(drawable_India);

        Drawable drawable_Korea = ResourcesCompat.getDrawable(getResources(),R.drawable.southkorea,null);
        mKoreaView.setImageDrawable(drawable_Korea);

        Drawable drawable_Taiwan = ResourcesCompat.getDrawable(getResources(),R.drawable.taiwan,null);
        mTaiwanView.setImageDrawable(drawable_Taiwan);

        Drawable drawable_Malaysia = ResourcesCompat.getDrawable(getResources(),R.drawable.malaysia,null);
        mMalaysiaView.setImageDrawable(drawable_Malaysia);

        Drawable drawable_Colombia = ResourcesCompat.getDrawable(getResources(),R.drawable.colombia,null);
        mColumbiaView.setImageDrawable(drawable_Colombia);

        Drawable drawable_Indonesia = ResourcesCompat.getDrawable(getResources(),R.drawable.indonesia,null);
        mIndonesiaView.setImageDrawable(drawable_Indonesia);

        mEditText = (EditText) findViewById(R.id.editText);

        mCategoryTextView.setText("");
        mEditText.setVisibility(View.GONE);
        spinner.setVisibility(View.GONE);
    }





    public void getCurrency(View view){
        //display all currency mode
        mEditText.setVisibility(View.VISIBLE);
        spinner.setVisibility(View.VISIBLE);



        mCategoryTextView.setText("Currency");


        mUSText4.setText("USD(US$)");
        mCanadaText4.setText("CAD(C$)");
        mChinatext4.setText("CNY()");
        mIndiatext4.setText("INR()");
        mKoreatext4.setText("KRW()");
        mTaiwantext4.setText("NTD(NT$)");
        mMalaysiatext4.setText("MYR(RM)");
        mColumbiatext4.setText("COP(COL$)");
        mIndonesiatext4.setText("IDR(Rp)");

        //add onclicklistener for both edittext and spinner


        mEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.length() == 0){
                    mUSText3.setText("0.0");
                    mCanadaText3.setText("0.0");
                    mKoreatext3.setText("0.0");
                    mChinatext3.setText("0.0");
                    mTaiwantext3.setText("0.0");
                    mIndonesiatext3.setText("0.0");
                    mMalaysiatext3.setText("0.0");
                    mIndiatext3.setText("0.0");
                    mColumbiatext3.setText("0.0");



                }
                else{
                    mUSText3.setText(editable);
                    num = Double.parseDouble(editable.toString());
                    Double USnum = num * usVal;
                    Double CADnum = num * cadVal;
                    Double Indonum = num * indoVal;
                    Double Chinanum = num * chinaVal;
                    Double Taiwanum = num * taiVal;
                    Double Colnum = num * colVal;
                    Double Malaynum = num * malayVal;
                    Double Indianum = num * indiaVal;
                    Double KORnum = num * korVal;

                    DecimalFormat df = new DecimalFormat("#.##");



                    mUSText3.setText(df.format(USnum));
                    mCanadaText3.setText(df.format(CADnum));
                    mKoreatext3.setText(df.format(KORnum));
                    mChinatext3.setText(df.format(Chinanum));
                    mTaiwantext3.setText(df.format(Taiwanum));
                    mColumbiatext3.setText(df.format(Colnum));
                    mMalaysiatext3.setText(df.format(Malaynum));
                    mIndonesiatext3.setText(df.format(Indonum));
                    mIndiatext3.setText(df.format(Indianum));


                }
            }
        });



        //Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item,Countries_Currency );

        //specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //place each view-item inside listview by setting adapter for our listview
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                String con = Countries_Currency[position];
                //Toast.makeText(getApplicationContext(),con, Toast.LENGTH_SHORT).show();






               if(con.equals("USD")){
                    cadVal = 1.3;
                    korVal = 1181.0;
                    usVal = 1.0;
                    indiaVal = 71.0;
                    colVal = 3453.29;
                    taiVal = 30.59;
                    indoVal = 14144.0;
                    chinaVal=7.08 ;
                    malayVal =4.19 ;

                }
               else if(con.equals("CAD")){
                    usVal = 0.76;
                    korVal = 898.87;
                    cadVal = 1.0;
                   indiaVal = 54.15;
                   colVal = 2629.23;
                   taiVal = 23.29;
                   indoVal = 10756.25;
                   chinaVal=5.39 ;
                   malayVal =3.19 ;

               }
                else if(con.equals("CNY")){
                   usVal = 0.14;
                   korVal = 166.72;
                   cadVal = 0.19;
                   indiaVal = 10.04;
                   colVal = 487.6;
                   taiVal = 4.32;
                   indoVal = 1998.04;
                   chinaVal= 1.0 ;
                   malayVal =0.59 ;
                }
                else if(con.equals("INR")){
                   usVal = 0.014;
                   korVal = 16.60;
                   cadVal = 0.018;
                   indiaVal = 1.0;
                   colVal = 48.56;
                   taiVal = 0.43;
                   indoVal = 199.07;
                   chinaVal= 0.1;
                   malayVal =0.059 ;
                }
                else if(con.equals("KRW")){
                   usVal = 0.00085;
                   korVal = 1.0;
                   cadVal = 0.0011;
                   indiaVal = 0.060;
                   colVal = 2.93;
                   taiVal = 0.026;
                   indoVal = 11.97;
                   chinaVal= 0.006;
                   malayVal =0.0035 ;
                }
                else if(con.equals("NTD")){
                   usVal = 0.033;
                   korVal = 38.59;
                   cadVal = 0.043;
                   indiaVal = 2.32;
                   colVal = 112.91;
                   taiVal = 1.0;
                   indoVal = 462.69;
                   chinaVal= 0.23 ;
                   malayVal =0.14 ;
                }
                else if(con.equals("MYR")){
                   usVal = 0.24;
                   korVal = 281.94;
                   cadVal = 0.31;
                   indiaVal = 16.99;
                   colVal = 825.04;
                   taiVal = 7.31;
                   indoVal = 3384.3;
                   chinaVal= 1.69 ;
                   malayVal =1.0 ;
                }
                else if(con.equals("COP")){
                   usVal = 0.00029;
                   korVal = 0.34;
                   cadVal = 0.00038;
                   indiaVal = 0.021;
                   colVal = 1.0;
                   taiVal = 0.0089;
                   indoVal = 4.10;
                   chinaVal= 0.0021;
                   malayVal =0.0012 ;
                }
                else if(con.equals("IDR")){
                   usVal = 0.000071;
                   korVal = 0.084;
                   cadVal = 0.000093;
                   indiaVal = 0.005;
                   colVal = 0.24;
                   taiVal = 0.0022;
                   indoVal = 1.0;
                   chinaVal= 0.0005 ;
                   malayVal =0.0003 ;
                }
                DecimalFormat df = new DecimalFormat("#.##");

                Double us1 = usVal  * num;
                Double kor1 = korVal  * num;
                Double cad1 = cadVal * num;
                Double tai1 = taiVal * num;
                Double indo1 = indoVal * num;
                Double indi1= indiaVal* num;
                Double malay1=malayVal *num;
                Double col1 = colVal * num;
                Double chi1 = chinaVal * num;



                mUSText3.setText(df.format(us1));
                mCanadaText3.setText(df.format(cad1));
                mKoreatext3.setText(df.format(kor1));
                mChinatext3.setText(df.format(chi1));
                mTaiwantext3.setText(df.format(tai1));
                mMalaysiatext3.setText(df.format(malay1));
                mColumbiatext3.setText(df.format(col1));
                mIndiatext3.setText(df.format(indi1));
                mIndonesiatext3.setText(df.format(indo1));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }






    public void getTime(View view){
        //display all time mode
        mCategoryTextView.setText("Time");


        mEditText.setVisibility(View.VISIBLE);
        spinner.setVisibility(View.VISIBLE);

        mUSText4.setText("");
        mCanadaText4.setText("");
        mChinatext4.setText("");
        mKoreatext4.setText("");
        mIndiatext4.setText("");
        mTaiwantext4.setText("");
        mIndonesiatext4.setText("");
        mColumbiatext4.setText("");
        mMalaysiatext4.setText("");

        DateFormat dateFormat = new SimpleDateFormat("kk:mm");
        Date date = new Date();
        mUSText3.setText(dateFormat.format(date));



        mEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {


            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.length() == 5) {
                    String hour = editable.toString().substring(0,2);
                    String min = editable.toString().substring(3);

                    Integer numHour = Integer.parseInt(hour);
                    Integer numMin = Integer.parseInt(min);



                    mUSText3.setText(hour+":"+min);
                }
            }

        });


        //add onclicklistener for both edittext and spinner
        spinner = (Spinner)findViewById(R.id.spinner);

        //Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item,Countries_Time );

        //specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //place each view-item inside listview by setting adapter for our listview
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                String con = Countries_Time[position];
                //Toast.makeText(getApplicationContext(),con, Toast.LENGTH_SHORT).show();



                if(con.equals("US")){


                }
                else if(con.equals("Canada")){

                }
                else if(con.equals("China")){

                }
                else if(con.equals("India")){

                }
                else if(con.equals("Korea")){

                }
                else if(con.equals("Taiwan")){

                }
                else if(con.equals("Malaysia")){

                }
                else if(con.equals("Colombia")){

                }
                else if(con.equals("Indonesia")){

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }





    public void getInfo(View view){
        Intent mintent = new Intent(this,Information.class);
        startActivity(mintent);
    }
}
