package org.cnit355jieun.converterapp_jy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Information extends AppCompatActivity {

    TextView title;
    TextView minfo;
    Button mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        mButton = findViewById(R.id.button);
        title = findViewById(R.id.textView);

        minfo = findViewById(R.id.informationText);
        minfo.setText("Thank you for using this unit converter. " +
                " This app was developed as part of Purdue CNIT 355 programming assignment. " +
                "If you have any questions, please email at you44@purdue.edu.");

    }

    public void MoveToMainActivity(View view){
        finish();
    }
}
